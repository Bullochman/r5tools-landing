# Fallback: Single Hero Tweet (thread pulled)

**When to use this instead of the 12-tweet thread:**
- Twitter API/composer is misbehaving and threads keep breaking
- You have <10 min and can't babysit a thread
- Analytics from a recent thread showed >70% drop-off before tweet 3 (thread fatigue in the audience)
- You're posting from mobile in a bad-connection spot (thread scheduling is fragile there)

**Post window:** same as thread — Tuesday 8:15 PM ET.

**Media:** attach the 4-tile mosaic (`media/tweet-01-hero-mosaic-4tile-landing-heat-coal-freeze.png` once built). Falls back to `media/tweet-12-homepage-hero.png` if mosaic isn't ready.

---

## Variant A — Hero tweet + link (recommended, 269 chars)

```
Built 8 planning tools for our LWS alliance — landing, heat sim, coal calc, freeze risk, roster OCR, city cap, season timeline, hive grid.

R5 of RONY, WZ 2007. Free tier is real (no email). Code RONY-FREE unlocks the full suite for WZ 2007.

r5tools.io

#LastWarSurvival
```

**Verified:** 269 chars. Under 280.

---

## Variant B — Founder-voice pitch (263 chars)

Use if Variant A is running too "list-y" and the audience wants human context.

```
I'm R5 of RONY (WZ 2007). Our officer team spent 6 hours a week on landing coords in a Google Sheet. Rebuilt it into 8 tools — landing, heat, coal, freeze, roster, city cap, timeline, hive grid.

Free tier is real. r5tools.io — code RONY-FREE.

#LastWarSurvival
```

**Verified:** 263 chars.

---

## Variant C — Data hook (271 chars)

Use if the last few posts on the account trended on numbers/stats.

```
Analyzed 500 alliance seasons: coal reserve at Week 4 predicts finish position more than any other single metric.

Built the calc that budgets it (plus 7 other planning tools) at r5tools.io. Free tier — no email. Code RONY-FREE for WZ 2007.

#LastWarSurvival
```

**Verified:** 271 chars.

---

## Post-tweet follow-up (regardless of variant)

Within 30 min of posting the single tweet, quote-tweet it with:

```
Reply with which tool your alliance would use first — landing, heat, coal, freeze, roster, city cap, timeline, or hive grid. I'll answer every one.
```

**Verified:** 152 chars. Well under limit.

This gives the single-post version some of the thread's engagement mechanic without the fragility.
